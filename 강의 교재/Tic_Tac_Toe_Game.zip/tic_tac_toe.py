import random

class TicTacToe:
    def __init__(self):
        """TicTacToe 게임을 초기화합니다."""
        self.board = [[" " for _ in range(3)] for _ in range(3)]
        self.user_wins = 0
        self.computer_wins = 0
        self.draws = 0
    
    def print_board(self):
        """게임 보드를 콘솔에 출력합니다."""
        print("\n")
        print("    1   2   3")
        print("  ┌───┬───┬───┐")
        for i in range(3):
            print(f" {i+1} │ {self.board[i][0]} │ {self.board[i][1]} │ {self.board[i][2]} │")
            if i < 2:
                print("  ├───┼───┼───┤")
        print("  └───┴───┴───┘")
        print()
    
    def check_winner(self, player):
        """승리 조건을 확인합니다."""
        # 가로 확인
        for row in self.board:
            if all(cell == player for cell in row):
                return True
        
        # 세로 확인
        for col in range(3):
            if all(self.board[row][col] == player for row in range(3)):
                return True
        
        # 대각선 확인
        if all(self.board[i][i] == player for i in range(3)):
            return True
        
        if all(self.board[i][2-i] == player for i in range(3)):
            return True
        
        return False
    
    def is_board_full(self):
        """보드가 가득 찼는지 확인합니다."""
        return all(cell != " " for row in self.board for cell in row)
    
    def get_empty_cells(self):
        """빈 칸들의 좌표를 반환합니다."""
        empty_cells = []
        for row in range(3):
            for col in range(3):
                if self.board[row][col] == " ":
                    empty_cells.append((row, col))
        return empty_cells
    
    def is_winning_move(self, row, col, player):
        """특정 위치에 수를 놓았을 때 승리하는지 확인합니다."""
        # 임시로 수를 놓아보고 승리하는지 확인
        self.board[row][col] = player
        is_win = self.check_winner(player)
        self.board[row][col] = " "  # 원래대로 복원
        return is_win
    
    def computer_move(self):
        """컴퓨터가 전략적으로 수를 둡니다."""
        empty_cells = self.get_empty_cells()
        if not empty_cells:
            return None
        
        # 1. 이길 수 있는 자리가 있는지 확인
        for row, col in empty_cells:
            if self.is_winning_move(row, col, "O"):
                print(f"컴퓨터가 ({row+1}, {col+1})에 O를 놓아 승리했습니다!")
                return row, col
        
        # 2. 상대방이 이길 수 있는 자리를 막기
        for row, col in empty_cells:
            if self.is_winning_move(row, col, "X"):
                print(f"컴퓨터가 ({row+1}, {col+1})에 O를 놓아 상대방을 막았습니다!")
                return row, col
        
        # 3. 중앙이 비어있으면 중앙 선택
        if self.board[1][1] == " ":
            print("컴퓨터가 중앙(2, 2)에 O를 놓았습니다.")
            return 1, 1
        
        # 4. 모서리 중 하나 선택 (전략적 우선순위)
        corners = [(0, 0), (0, 2), (2, 0), (2, 2)]
        available_corners = [(row, col) for row, col in corners if self.board[row][col] == " "]
        if available_corners:
            row, col = random.choice(available_corners)
            print(f"컴퓨터가 모서리({row+1}, {col+1})에 O를 놓았습니다.")
            return row, col
        
        # 5. 그 외 빈 칸 중 랜덤 선택
        row, col = random.choice(empty_cells)
        print(f"컴퓨터가 ({row+1}, {col+1})에 O를 놓았습니다.")
        return row, col
    
    def get_valid_move(self):
        """사용자의 유효한 좌표 입력을 받습니다."""
        while True:
            try:
                row = int(input("행 번호를 입력하세요 (1-3): ")) - 1
                col = int(input("열 번호를 입력하세요 (1-3): ")) - 1
                
                if 0 <= row <= 2 and 0 <= col <= 2:
                    if self.board[row][col] == " ":
                        return row, col
                    else:
                        print("이미 선택된 위치입니다. 다시 선택해주세요.")
                else:
                    print("1-3 사이의 숫자를 입력해주세요.")
            except ValueError:
                print("올바른 숫자를 입력해주세요.")
    
    def player_move(self):
        """사용자(X)의 수를 받아 보드에 놓습니다."""
        print("사용자(X)의 차례입니다.")
        row, col = self.get_valid_move()
        self.board[row][col] = "X"
        return row, col
    
    def computer_turn(self):
        """컴퓨터(O)의 차례를 처리합니다."""
        print("\n컴퓨터(O)의 차례입니다...")
        row, col = self.computer_move()
        self.board[row][col] = "O"
        return row, col
    
    def check_game_result(self, player):
        """게임 결과를 확인합니다."""
        if self.check_winner(player):
            self.print_board()
            if player == "X":
                print("🎉 사용자(X)가 승리했습니다! 🎉")
            else:
                print("😅 컴퓨터(O)가 승리했습니다! 😅")
            return player
        elif self.is_board_full():
            self.print_board()
            print("🤝 무승부입니다! 🤝")
            return "draw"
        return None
    
    def play_single_game(self):
        """한 게임을 진행하는 메서드"""
        # 보드 초기화
        self.board = [[" " for _ in range(3)] for _ in range(3)]
        
        while True:
            # 현재 보드 출력
            self.print_board()
            
            # 사용자(X) 차례
            self.player_move()
            
            # 사용자 승리 확인
            result = self.check_game_result("X")
            if result:
                return "user" if result == "X" else "draw"
            
            # 컴퓨터(O) 차례
            self.computer_turn()
            
            # 컴퓨터 승리 확인
            result = self.check_game_result("O")
            if result:
                return "computer" if result == "O" else "draw"
    
    def display_statistics(self):
        """현재까지의 게임 통계를 출력합니다."""
        print("\n" + "="*50)
        print("📊 현재까지의 게임 결과:")
        print(f"   사용자(X) 승리: {self.user_wins}회")
        print(f"   컴퓨터(O) 승리: {self.computer_wins}회")
        print(f"   무승부: {self.draws}회")
        print(f"   총 게임 수: {self.user_wins + self.computer_wins + self.draws}회")
        print("="*50)
    
    def display_final_results(self):
        """최종 게임 결과를 출력합니다."""
        print("\n" + "="*50)
        print("🎮 최종 게임 결과:")
        print(f"   사용자(X) 승리: {self.user_wins}회")
        print(f"   컴퓨터(O) 승리: {self.computer_wins}회")
        print(f"   무승부: {self.draws}회")
        print(f"   총 게임 수: {self.user_wins + self.computer_wins + self.draws}회")
        
        if self.user_wins > self.computer_wins:
            print("🏆 최종 승자: 사용자(X)! 🏆")
        elif self.computer_wins > self.user_wins:
            print("🏆 최종 승자: 컴퓨터(O)! 🏆")
        else:
            print("🤝 최종 결과: 무승부! 🤝")
        
        print("="*50)
    
    def ask_play_again(self):
        """게임 재시작 여부를 묻습니다."""
        while True:
            play_again = input("\n게임을 다시 하시겠습니까? (y/n): ").lower()
            if play_again in ['y', 'yes', '예']:
                return True
            elif play_again in ['n', 'no', '아니오']:
                return False
            else:
                print("y 또는 n을 입력해주세요.")
    
    def play(self):
        """메인 게임을 실행하는 메서드"""
        print("=== Tic Tac Toe 게임 ===")
        print("사용자(X) vs 컴퓨터(O)")
        print("좌표는 (행, 열) 형태로 입력합니다. (예: 1행 2열 = 1, 2)")
        
        while True:
            # 게임 진행
            result = self.play_single_game()
            
            # 결과에 따른 통계 업데이트
            if result == "user":
                self.user_wins += 1
            elif result == "computer":
                self.computer_wins += 1
            else:
                self.draws += 1
            
            # 현재까지의 통계 출력
            self.display_statistics()
            
            # 게임 재시작 여부 확인
            if self.ask_play_again():
                print("\n새로운 게임을 시작합니다!")
            else:
                self.display_final_results()
                print("게임을 종료합니다. 감사합니다!")
                break

def main():
    """메인 함수 - 게임 인스턴스를 생성하고 실행합니다."""
    game = TicTacToe()
    game.play()

if __name__ == "__main__":
    main()
