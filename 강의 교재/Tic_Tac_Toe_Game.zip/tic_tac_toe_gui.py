import tkinter as tk
from tkinter import messagebox
import random

class TicTacToeGUI:
    def __init__(self, root):
        """TicTacToe GUI 게임을 초기화합니다."""
        self.root = root
        self.root.title("Tic Tac Toe - 사용자(X) vs 컴퓨터(O)")
        self.root.geometry("500x800")
        self.root.resizable(False, False)
        
        # 색상 테마 설정
        self.bg_color = "#f0f0f0"  # 배경색
        self.title_color = "#2c3e50"  # 제목 색상
        self.button_bg = "#ecf0f1"  # 버튼 배경색
        self.button_active_bg = "#bdc3c7"  # 버튼 활성화 색상
        self.x_color = "#3498db"  # X 색상 (파란색)
        self.o_color = "#e74c3c"  # O 색상 (빨간색)
        self.status_color = "#34495e"  # 상태 메시지 색상
        
        # 창 배경색 설정
        self.root.configure(bg=self.bg_color)
        
        # 게임 상태 초기화
        self.board = [[" " for _ in range(3)] for _ in range(3)]
        self.game_over = False
        self.user_wins = 0
        self.computer_wins = 0
        self.draws = 0
        
        # GUI 구성
        self.create_widgets()
        
        # 게임 시작
        self.update_status("사용자(X)의 차례입니다. 보드를 클릭하세요!")
    
    def create_widgets(self):
        """GUI 위젯들을 생성합니다."""
        # 제목
        title_label = tk.Label(
            self.root, 
            text="Tic Tac Toe", 
            font=("Arial", 28, "bold"),
            fg=self.title_color,
            bg=self.bg_color
        )
        title_label.pack(pady=25)
        
        # 상태 표시
        self.status_label = tk.Label(
            self.root, 
            text="", 
            font=("Arial", 14),
            fg=self.status_color,
            bg=self.bg_color
        )
        self.status_label.pack(pady=15)
        
        # 게임 보드 프레임
        board_frame = tk.Frame(self.root, bg=self.bg_color)
        board_frame.pack(pady=35)
        
        # 3x3 버튼 그리드 생성
        self.buttons = []
        for i in range(3):
            row = []
            for j in range(3):
                button = tk.Button(
                    board_frame,
                    text="",
                    font=("Arial", 24, "bold"),
                    width=8,
                    height=4,
                    bg=self.button_bg,
                    activebackground=self.button_active_bg,
                    relief=tk.RAISED,
                    borderwidth=3,
                    command=lambda row=i, col=j: self.button_click(row, col)
                )
                button.grid(row=i, column=j, padx=4, pady=4)
                row.append(button)
            self.buttons.append(row)
        
        # 통계 프레임
        stats_frame = tk.Frame(self.root, bg=self.bg_color)
        stats_frame.pack(pady=25)
        
        # 통계 라벨들
        self.user_wins_label = tk.Label(
            stats_frame, 
            text="사용자(X): 0", 
            font=("Arial", 12, "bold"),
            fg=self.x_color,
            bg=self.bg_color
        )
        self.user_wins_label.pack(side=tk.LEFT, padx=15)
        
        self.computer_wins_label = tk.Label(
            stats_frame, 
            text="컴퓨터(O): 0", 
            font=("Arial", 12, "bold"),
            fg=self.o_color,
            bg=self.bg_color
        )
        self.computer_wins_label.pack(side=tk.LEFT, padx=15)
        
        self.draws_label = tk.Label(
            stats_frame, 
            text="무승부: 0", 
            font=("Arial", 12, "bold"),
            fg="#7f8c8d",
            bg=self.bg_color
        )
        self.draws_label.pack(side=tk.LEFT, padx=15)
        
        # 새 게임 버튼
        new_game_button = tk.Button(
            self.root,
            text="새 게임",
            font=("Arial", 14, "bold"),
            bg="#27ae60",
            fg="white",
            activebackground="#229954",
            activeforeground="white",
            relief=tk.RAISED,
            borderwidth=2,
            padx=20,
            pady=8,
            command=self.new_game
        )
        new_game_button.pack(pady=25)
    
    def button_click(self, row, col):
        """버튼 클릭 이벤트를 처리합니다."""
        if self.game_over or self.board[row][col] != " ":
            return
        
        # 사용자(X) 수 두기
        self.board[row][col] = "X"
        self.buttons[row][col].config(
            text="X", 
            fg=self.x_color, 
            bg="#d6eaf8",
            state=tk.DISABLED
        )
        
        # 사용자 승리 확인
        if self.check_winner("X"):
            self.game_over = True
            self.user_wins += 1
            self.update_statistics()
            self.update_status("🎉 사용자(X)가 승리했습니다! 🎉")
            self.show_game_end_popup("사용자(X) 승리!", "🎉 축하합니다! 사용자(X)가 승리했습니다!")
            return
        
        # 무승부 확인
        if self.is_board_full():
            self.game_over = True
            self.draws += 1
            self.update_statistics()
            self.update_status("🤝 무승부입니다! 🤝")
            self.show_game_end_popup("무승부!", "🤝 이번 게임은 무승부입니다!")
            return
        
        # 컴퓨터(O) 차례
        self.update_status("컴퓨터(O)가 생각하고 있습니다...")
        self.root.after(500, self.computer_move)  # 0.5초 후 컴퓨터 수 두기
    
    def computer_move(self):
        """Minimax 알고리즘을 사용하여 최적의 수를 둡니다."""
        empty_cells = self.get_empty_cells()
        if not empty_cells:
            return
        
        # 첫 번째 수인 경우 중앙 선택 (최적 전략)
        if len(empty_cells) == 9:
            self.make_computer_move(1, 1, "중앙을 선택했습니다!")
            return
        
        # Minimax 알고리즘으로 최적의 수 찾기
        best_score = float('-inf')
        best_move = None
        
        for row, col in empty_cells:
            # 임시로 수를 놓아보기
            self.board[row][col] = "O"
            score = self.minimax(self.board, 0, False, float('-inf'), float('inf'))
            self.board[row][col] = " "  # 원래대로 복원
            
            if score > best_score:
                best_score = score
                best_move = (row, col)
        
        # 최적의 수를 두기
        if best_move:
            row, col = best_move
            self.make_computer_move(row, col, "최적의 수를 선택했습니다!")
    
    def minimax(self, board, depth, is_maximizing, alpha, beta):
        """Minimax 알고리즘 (Alpha-Beta 가지치기 포함)"""
        # 종료 조건 확인
        if self.check_winner_minimax(board, "O"):
            return 10 - depth  # 컴퓨터 승리 (깊이가 낮을수록 높은 점수)
        if self.check_winner_minimax(board, "X"):
            return depth - 10  # 사용자 승리 (깊이가 낮을수록 낮은 점수)
        if self.is_board_full_minimax(board):
            return 0  # 무승부
        
        # 최대 깊이 제한 (성능 최적화)
        if depth >= 8:
            return 0
        
        if is_maximizing:
            max_score = float('-inf')
            for row in range(3):
                for col in range(3):
                    if board[row][col] == " ":
                        board[row][col] = "O"
                        score = self.minimax(board, depth + 1, False, alpha, beta)
                        board[row][col] = " "
                        max_score = max(max_score, score)
                        alpha = max(alpha, score)
                        if beta <= alpha:
                            break
                if beta <= alpha:
                    break
            return max_score
        else:
            min_score = float('inf')
            for row in range(3):
                for col in range(3):
                    if board[row][col] == " ":
                        board[row][col] = "X"
                        score = self.minimax(board, depth + 1, True, alpha, beta)
                        board[row][col] = " "
                        min_score = min(min_score, score)
                        beta = min(beta, score)
                        if beta <= alpha:
                            break
                if beta <= alpha:
                    break
            return min_score
    
    def check_winner_minimax(self, board, player):
        """Minimax용 승리 조건 확인 (self.board 대신 board 매개변수 사용)"""
        # 가로 확인
        for row in board:
            if all(cell == player for cell in row):
                return True
        
        # 세로 확인
        for col in range(3):
            if all(board[row][col] == player for row in range(3)):
                return True
        
        # 대각선 확인
        if all(board[i][i] == player for i in range(3)):
            return True
        
        if all(board[i][2-i] == player for i in range(3)):
            return True
        
        return False
    
    def is_board_full_minimax(self, board):
        """Minimax용 보드 가득참 확인 (self.board 대신 board 매개변수 사용)"""
        return all(cell != " " for row in board for cell in row)
    
    def make_computer_move(self, row, col, reason):
        """컴퓨터의 수를 보드에 놓고 결과를 확인합니다."""
        self.board[row][col] = "O"
        self.buttons[row][col].config(
            text="O", 
            fg=self.o_color, 
            bg="#fadbd8",
            state=tk.DISABLED
        )
        
        # 컴퓨터 승리 확인
        if self.check_winner("O"):
            self.game_over = True
            self.computer_wins += 1
            self.update_statistics()
            self.update_status("😅 컴퓨터(O)가 승리했습니다! 😅")
            self.show_game_end_popup("컴퓨터(O) 승리!", "😅 아쉽습니다! 컴퓨터(O)가 승리했습니다!")
            return
        
        # 무승부 확인
        if self.is_board_full():
            self.game_over = True
            self.draws += 1
            self.update_statistics()
            self.update_status("🤝 무승부입니다! 🤝")
            self.show_game_end_popup("무승부!", "🤝 이번 게임은 무승부입니다!")
            return
        
        # 사용자 차례
        self.update_status("사용자(X)의 차례입니다. 보드를 클릭하세요!")
    
    def check_winner(self, player):
        """승리 조건을 확인합니다."""
        # 가로 확인
        for row in self.board:
            if all(cell == player for cell in row):
                return True
        
        # 세로 확인
        for col in range(3):
            if all(self.board[row][col] == player for row in range(3)):
                return True
        
        # 대각선 확인
        if all(self.board[i][i] == player for i in range(3)):
            return True
        
        if all(self.board[i][2-i] == player for i in range(3)):
            return True
        
        return False
    
    def is_board_full(self):
        """보드가 가득 찼는지 확인합니다."""
        return all(cell != " " for row in self.board for cell in row)
    
    def get_empty_cells(self):
        """빈 칸들의 좌표를 반환합니다."""
        empty_cells = []
        for row in range(3):
            for col in range(3):
                if self.board[row][col] == " ":
                    empty_cells.append((row, col))
        return empty_cells
    
    def is_winning_move(self, row, col, player):
        """특정 위치에 수를 놓았을 때 승리하는지 확인합니다."""
        # 임시로 수를 놓아보고 승리하는지 확인
        self.board[row][col] = player
        is_win = self.check_winner(player)
        self.board[row][col] = " "  # 원래대로 복원
        return is_win
    
    def update_status(self, message):
        """상태 메시지를 업데이트합니다."""
        self.status_label.config(text=message)
    
    def update_statistics(self):
        """통계를 업데이트합니다."""
        self.user_wins_label.config(text=f"사용자(X): {self.user_wins}")
        self.computer_wins_label.config(text=f"컴퓨터(O): {self.computer_wins}")
        self.draws_label.config(text=f"무승부: {self.draws}")
    
    def show_game_end_popup(self, title, message):
        """게임 종료 시 팝업을 표시하고 재시작 여부를 묻습니다."""
        result = messagebox.askyesno(title, f"{message}\n\n새로운 게임을 시작하시겠습니까?")
        if result:
            self.new_game()
        else:
            # 게임 종료 시 모든 버튼을 비활성화
            for i in range(3):
                for j in range(3):
                    self.buttons[i][j].config(
                        state=tk.DISABLED,
                        bg="#bdc3c7"
                    )
            self.update_status("게임이 종료되었습니다. '새 게임' 버튼을 클릭하여 다시 시작하세요.")
    
    def new_game(self):
        """새 게임을 시작합니다."""
        # 보드 초기화
        self.board = [[" " for _ in range(3)] for _ in range(3)]
        self.game_over = False
        
        # 버튼 초기화
        for i in range(3):
            for j in range(3):
                self.buttons[i][j].config(
                    text="", 
                    fg="black", 
                    bg=self.button_bg,
                    state=tk.NORMAL
                )
        
        # 상태 초기화
        self.update_status("새 게임이 시작되었습니다! 사용자(X)의 차례입니다.")

def main():
    """메인 함수"""
    root = tk.Tk()
    game = TicTacToeGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
