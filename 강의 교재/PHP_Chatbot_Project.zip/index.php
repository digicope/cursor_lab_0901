<?php
session_start();

// 세션 ID 생성 (없는 경우)
if (!isset($_SESSION['session_id'])) {
    $_SESSION['session_id'] = uniqid('chat_', true);
}

// 대화 히스토리 초기화 (세션별)
if (!isset($_SESSION['conversation_history'])) {
    $_SESSION['conversation_history'] = [];
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>웹 챗봇</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Malgun Gothic', sans-serif;
            background: #f2f3f5;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .chat-container {
            width: 100%;
            max-width: 400px;
            height: 100vh;
            background: white;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .chat-header {
            background: #fee500;
            color: #3c1e1e;
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #e0e0e0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .back-button {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            color: #3c1e1e;
        }

        .chat-title {
            font-size: 18px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            gap: 8px;
        }

        .header-button {
            background: none;
            border: none;
            font-size: 16px;
            cursor: pointer;
            color: #3c1e1e;
            padding: 4px;
        }

        .chat-messages {
            flex: 1;
            padding: 16px;
            overflow-y: auto;
            background: #f2f3f5;
        }

        .message {
            margin-bottom: 8px;
            display: flex;
            align-items: flex-end;
        }

        .message.user {
            justify-content: flex-end;
        }

        .message.bot {
            justify-content: flex-start;
        }

        .message-content {
            max-width: 75%;
            padding: 8px 12px;
            border-radius: 18px;
            word-wrap: break-word;
            line-height: 1.4;
            font-size: 15px;
            position: relative;
        }

        .message.user .message-content {
            background: #fee500;
            color: #3c1e1e;
            border-bottom-right-radius: 4px;
        }

        .message.bot .message-content {
            background: white;
            color: #333;
            border-bottom-left-radius: 4px;
            border: 1px solid #e0e0e0;
        }

        .message-time {
            font-size: 11px;
            color: #8e8e93;
            margin: 0 4px;
            align-self: flex-end;
            margin-bottom: 2px;
        }

        .message.user .message-time {
            order: -1;
        }

        .chat-input-container {
            padding: 12px 16px;
            background: white;
            border-top: 1px solid #e0e0e0;
            display: flex;
            align-items: flex-end;
            gap: 8px;
        }

        .input-wrapper {
            flex: 1;
            display: flex;
            align-items: flex-end;
            background: #f2f3f5;
            border-radius: 20px;
            padding: 8px 12px;
            min-height: 40px;
        }

        .chat-input {
            flex: 1;
            border: none;
            background: none;
            font-size: 15px;
            outline: none;
            resize: none;
            max-height: 100px;
            font-family: inherit;
        }

        .chat-input::placeholder {
            color: #8e8e93;
        }

        .send-button {
            width: 40px;
            height: 40px;
            background: #fee500;
            color: #3c1e1e;
            border: none;
            border-radius: 50%;
            font-size: 16px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.2s;
        }

        .send-button:hover {
            background: #fdd835;
        }

        .send-button:disabled {
            background: #e0e0e0;
            color: #8e8e93;
            cursor: not-allowed;
        }

        .loading {
            display: none;
            text-align: center;
            color: #8e8e93;
            font-size: 13px;
            margin: 8px 0;
        }

        .error {
            background: #ffebee;
            color: #c62828;
            padding: 8px 12px;
            border-radius: 18px;
            margin: 8px 0;
            font-size: 14px;
        }

        /* 스크롤바 스타일링 */
        .chat-messages::-webkit-scrollbar {
            width: 4px;
        }

        .chat-messages::-webkit-scrollbar-track {
            background: transparent;
        }

        .chat-messages::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 2px;
        }

        .chat-messages::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        /* 말풍선 꼬리 효과 */
        .message.user .message-content::after {
            content: '';
            position: absolute;
            bottom: 0;
            right: -6px;
            width: 0;
            height: 0;
            border: 6px solid transparent;
            border-left-color: #fee500;
            border-bottom: none;
        }

        .message.bot .message-content::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: -6px;
            width: 0;
            height: 0;
            border: 6px solid transparent;
            border-right-color: white;
            border-bottom: none;
        }

        /* 반응형 디자인 */
        @media (max-width: 480px) {
            .chat-container {
                max-width: 100%;
                height: 100vh;
            }
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            <div class="header-left">
                <button class="back-button">‹</button>
                <div class="chat-title">AI 챗봇</div>
            </div>
            <div class="header-right">
                <button class="header-button" onclick="clearHistory()" title="대화 초기화">🗑️</button>
                <button class="header-button">⋯</button>
            </div>
        </div>
        
        <div class="chat-messages" id="chatMessages">
            <div class="message bot">
                <div class="message-content">
                    안녕하세요! 무엇을 도와드릴까요?
                </div>
                <div class="message-time"><?php echo date('a g:i'); ?></div>
            </div>
        </div>
        
        <div class="loading" id="loading">
            챗봇이 답변을 생성하고 있습니다...
        </div>
        
        <div class="chat-input-container">
            <div class="input-wrapper">
                <textarea 
                    class="chat-input" 
                    id="messageInput" 
                    placeholder="메시지를 입력하세요..."
                    autocomplete="off"
                    rows="1"
                ></textarea>
            </div>
            <button class="send-button" id="sendButton" onclick="sendMessage()">
                ›
            </button>
        </div>
    </div>

    <script>
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        const chatMessages = document.getElementById('chatMessages');
        const loading = document.getElementById('loading');

        // Enter 키로 메시지 전송 (Shift+Enter는 줄바꿈)
        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        // 텍스트 영역 자동 높이 조절
        messageInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        });

        async function sendMessage() {
            const message = messageInput.value.trim();
            
            if (!message) {
                return;
            }

            // UI 상태 변경
            messageInput.value = '';
            messageInput.style.height = 'auto';
            sendButton.disabled = true;
            loading.style.display = 'block';

            // 사용자 메시지 표시
            addMessage(message, 'user');

            try {
                const response = await fetch('chat.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'message=' + encodeURIComponent(message)
                });

                const data = await response.json();

                if (response.ok) {
                    // 봇 응답 표시
                    addMessage(data.bot_response, 'bot');
                } else {
                    // 에러 메시지 표시
                    addMessage(`오류: ${data.error}`, 'bot');
                }
            } catch (error) {
                console.error('Error:', error);
                addMessage('네트워크 오류가 발생했습니다. 다시 시도해주세요.', 'bot');
            } finally {
                // UI 상태 복원
                sendButton.disabled = false;
                loading.style.display = 'none';
                messageInput.focus();
            }
        }

        function addMessage(content, sender) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${sender}`;
            
            const messageContent = document.createElement('div');
            messageContent.className = 'message-content';
            messageContent.textContent = content;
            
            const messageTime = document.createElement('div');
            messageTime.className = 'message-time';
            messageTime.textContent = getCurrentTime();
            
            if (sender === 'user') {
                messageDiv.appendChild(messageTime);
                messageDiv.appendChild(messageContent);
            } else {
                messageDiv.appendChild(messageContent);
                messageDiv.appendChild(messageTime);
            }
            
            chatMessages.appendChild(messageDiv);
            
            // 스크롤을 맨 아래로
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function getCurrentTime() {
            const now = new Date();
            const hours = now.getHours();
            const minutes = now.getMinutes();
            const period = hours >= 12 ? '오후' : '오전';
            const displayHours = hours > 12 ? hours - 12 : (hours === 0 ? 12 : hours);
            return `${period} ${displayHours}:${minutes.toString().padStart(2, '0')}`;
        }

        // 대화 히스토리 초기화
        async function clearHistory() {
            if (confirm('대화 히스토리를 초기화하시겠습니까?')) {
                try {
                    const response = await fetch('clear_history.php', {
                        method: 'POST'
                    });

                    const data = await response.json();

                    if (response.ok) {
                        // 채팅창 초기화
                        chatMessages.innerHTML = `
                            <div class="message bot">
                                <div class="message-content">
                                    안녕하세요! 무엇을 도와드릴까요?
                                </div>
                                <div class="message-time">${getCurrentTime()}</div>
                            </div>
                        `;
                        alert('대화 히스토리가 초기화되었습니다.');
                    } else {
                        alert(`오류: ${data.error}`);
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('네트워크 오류가 발생했습니다.');
                }
            }
        }

        // 페이지 로드 시 입력창에 포커스
        window.addEventListener('load', function() {
            messageInput.focus();
        });
    </script>
</body>
</html>
