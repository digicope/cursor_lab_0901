<?php
// PHP 챗봇 설정 파일

// OpenAI API 키 설정
// dothome에서는 환경변수 대신 직접 설정하거나 별도 파일에서 로드
$config = [
    'openai_api_key' => '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', // 실제 API 키로 변경하세요
    'model' => 'gpt-4o-mini',
    'max_tokens' => 1000,
    'temperature' => 0.7,
    'max_history' => 10, // 최대 대화 히스토리 개수
    'session_timeout' => 3600, // 세션 타임아웃 (초)
];

// API 키를 별도 파일에서 로드하는 경우 (보안상 권장)
// $api_key_file = __DIR__ . '/api_key.txt';
// if (file_exists($api_key_file)) {
//     $config['openai_api_key'] = trim(file_get_contents($api_key_file));
// }

return $config;
?>
