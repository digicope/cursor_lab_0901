# PHP 웹 챗봇 프로젝트

PHP와 OpenAI API를 사용한 웹 챗봇입니다. dothome 호스팅에 최적화되어 있습니다.

## 기능

- 실시간 채팅 인터페이스
- OpenAI GPT-4o-mini 모델 사용
- 카카오톡과 동일한 디자인
- 대화 히스토리 저장 및 맥락 인식
- 세션별 대화 관리
- 대화 히스토리 초기화 기능
- AJAX를 사용한 비동기 통신
- 반응형 디자인

## dothome 호스팅 설정

### 1. 파일 업로드
1. dothome FTP에 접속
2. `public_html` 폴더에 모든 파일 업로드
3. 파일 권한 설정 (PHP 파일: 644, 폴더: 755)

### 2. API 키 설정
`config.php` 파일에서 OpenAI API 키를 설정하세요:
```php
$config = [
    'openai_api_key' => 'your_actual_openai_api_key_here',
    // ... 기타 설정
];
```

### 3. 보안 설정 (선택사항)
API 키를 별도 파일로 관리하려면:
1. `api_key.txt` 파일 생성
2. API 키만 입력
3. `config.php`에서 주석 해제

## 파일 구조

```
PHP_Chatbot_Project/
├── index.php              # 메인 페이지
├── chat.php               # 채팅 API 엔드포인트
├── clear_history.php      # 대화 히스토리 초기화
├── history.php            # 대화 히스토리 조회
├── config.php             # 설정 파일
├── .htaccess              # Apache 설정
└── README.md              # 프로젝트 설명
```

## 사용법

1. dothome에 파일 업로드 후 `your-domain.com` 접속
2. 하단의 입력창에 메시지를 입력합니다.
3. "전송" 버튼을 클릭하거나 Enter 키를 눌러 메시지를 전송합니다.
4. 챗봇이 응답을 생성하는 동안 로딩 메시지가 표시됩니다.
5. 챗봇의 응답이 채팅창에 표시됩니다.
6. 챗봇은 이전 대화의 맥락을 기억하여 더 자연스러운 대화를 제공합니다.
7. 헤더의 🗑️ 버튼을 클릭하여 대화 히스토리를 초기화할 수 있습니다.

## API 엔드포인트

- `POST /chat.php` - 채팅 메시지 전송
- `POST /clear_history.php` - 대화 히스토리 초기화
- `GET /history.php` - 대화 히스토리 조회

## 주의사항

- OpenAI API 키가 필요합니다.
- 인터넷 연결이 필요합니다.
- API 사용량에 따라 비용이 발생할 수 있습니다.
- dothome의 PHP 버전과 cURL 확장이 필요합니다.
- 세션은 서버 메모리에 저장되므로 서버 재시작 시 초기화됩니다.

## 문제 해결

### cURL 오류
dothome에서 cURL이 비활성화된 경우, `chat.php`에서 `file_get_contents`를 사용하도록 수정할 수 있습니다.

### 세션 문제
세션이 제대로 작동하지 않는 경우, dothome의 세션 설정을 확인하세요.

### API 키 오류
OpenAI API 키가 올바른지 확인하고, API 사용량 한도를 확인하세요.
