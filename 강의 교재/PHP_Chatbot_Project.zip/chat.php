<?php
session_start();
header('Content-Type: application/json');

// 설정 파일 로드
$config = require_once 'config.php';
$openai_api_key = $config['openai_api_key'];

// 세션 ID 확인
if (!isset($_SESSION['session_id'])) {
    echo json_encode(['error' => '세션이 만료되었습니다. 페이지를 새로고침해주세요.']);
    exit;
}

// 대화 히스토리 초기화 (세션별)
if (!isset($_SESSION['conversation_history'])) {
    $_SESSION['conversation_history'] = [];
}

// POST 데이터 확인
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => '잘못된 요청 방법입니다.']);
    exit;
}

$user_message = $_POST['message'] ?? '';

if (empty($user_message)) {
    echo json_encode(['error' => '메시지가 비어있습니다.']);
    exit;
}

try {
    // 사용자 메시지를 히스토리에 추가
    $_SESSION['conversation_history'][] = [
        'role' => 'user',
        'content' => $user_message,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // OpenAI API 호출을 위한 메시지 배열 구성
    $messages = [
        [
            'role' => 'system',
            'content' => '당신은 도움이 되는 AI 어시스턴트입니다. 이전 대화의 맥락을 고려하여 자연스럽고 유용한 답변을 제공해주세요.'
        ]
    ];
    
    // 최근 대화만 포함 (토큰 제한 고려)
    $recent_history = array_slice($_SESSION['conversation_history'], -$config['max_history']);
    foreach ($recent_history as $msg) {
        $messages[] = [
            'role' => $msg['role'],
            'content' => $msg['content']
        ];
    }
    
    // OpenAI API 호출
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.openai.com/v1/chat/completions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $openai_api_key
    ]);
    
    $post_data = json_encode([
        'model' => $config['model'],
        'messages' => $messages,
        'max_tokens' => $config['max_tokens'],
        'temperature' => $config['temperature']
    ]);
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        throw new Exception('OpenAI API 호출 실패: HTTP ' . $http_code);
    }
    
    $response_data = json_decode($response, true);
    
    if (!isset($response_data['choices'][0]['message']['content'])) {
        throw new Exception('OpenAI API 응답 형식 오류');
    }
    
    $bot_response = $response_data['choices'][0]['message']['content'];
    
    // 봇 응답을 히스토리에 추가
    $_SESSION['conversation_history'][] = [
        'role' => 'assistant',
        'content' => $bot_response,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    echo json_encode([
        'user_message' => $user_message,
        'bot_response' => $bot_response
    ]);
    
} catch (Exception $e) {
    echo json_encode(['error' => '오류가 발생했습니다: ' . $e->getMessage()]);
}
?>
