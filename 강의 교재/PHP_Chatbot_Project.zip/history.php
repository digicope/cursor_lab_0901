<?php
session_start();
header('Content-Type: application/json');

try {
    // 현재 세션의 대화 히스토리 조회
    $history = $_SESSION['conversation_history'] ?? [];
    $count = count($history);
    
    echo json_encode([
        'history' => $history,
        'count' => $count
    ]);
    
} catch (Exception $e) {
    echo json_encode(['error' => '오류가 발생했습니다: ' . $e->getMessage()]);
}
?>
