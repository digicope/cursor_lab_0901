<?php
session_start();
header('Content-Type: application/json');

// POST 요청만 허용
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => '잘못된 요청 방법입니다.']);
    exit;
}

try {
    // 대화 히스토리 초기화
    $_SESSION['conversation_history'] = [];
    
    echo json_encode(['message' => '대화 히스토리가 초기화되었습니다.']);
    
} catch (Exception $e) {
    echo json_encode(['error' => '오류가 발생했습니다: ' . $e->getMessage()]);
}
?>
